/**
 * The main package for my File Browser.
 * There are two ways to use this program.
 * Maven (Recommended, also not sure if it works):
 * Grab the most recent artifact from github and pull it in as a dependancy.
 * Manual (working :P):
 * To use this in your project, simply copy and paste this package.
 * @author bram.zerbe
 *
 */
package com.ezreb.filebrowser;